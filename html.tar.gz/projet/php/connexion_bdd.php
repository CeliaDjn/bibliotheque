<?php
// Connexion à la base de données
$db = mysqli_connect('localhost', 'root', 'Password123#@!', 'biblio');

if (!$db) {
    die("La connexion à la base de données a échoué : " . mysqli_connect_error());
}

mysqli_set_charset($db, "utf8");
?>
